﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nucleus.Abstractions.Models.FileSystem;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using $nucleus.extension.namespace$.Models;
using Nucleus.Abstractions.Models;

namespace $nucleus.extension.namespace$.ViewModels
{
	public class Settings : Models.Settings
	{		

	}
}
