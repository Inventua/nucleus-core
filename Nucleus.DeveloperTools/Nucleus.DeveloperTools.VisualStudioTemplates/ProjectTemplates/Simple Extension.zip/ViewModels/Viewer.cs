﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nucleus.Abstractions.Models.FileSystem;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace $nucleus.extension.namespace$.ViewModels
{
	public class Viewer : Models.Settings
	{
		
	}
}
