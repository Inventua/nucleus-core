﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nucleus.Abstractions.Models;
using Nucleus.Abstractions.Models.FileSystem;

namespace $nucleus_extension_namespace$.Models
{
	public class $nucleus_extension_name$
	{
		public Guid Id { get; set; }				
	}
}
