﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nucleus.Abstractions.Models.FileSystem;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using $nucleus_extension_namespace$.Models;
using Nucleus.Abstractions.Models;

namespace $nucleus_extension_namespace$.ViewModels
{
	public class Settings : Models.Settings
	{		

	}
}
