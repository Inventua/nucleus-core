﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nucleus.Abstractions.Models;

namespace $nucleus_extension_namespace$.Models
{
	public class $nucleus_extension_modelname$ : ModelBase
	{
		public Guid Id { get; set; }				
	}
}
